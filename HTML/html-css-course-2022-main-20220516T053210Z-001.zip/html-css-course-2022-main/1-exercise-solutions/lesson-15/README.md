# Exercises
![exercises15-1](https://user-images.githubusercontent.com/70604577/160039784-d4f262bf-bb99-435d-b2f2-19e601077199.png)
![exercises15-2](https://user-images.githubusercontent.com/70604577/160039786-705b44e1-6173-4d02-848a-933a33c4d615.png)
![exercises15-3](https://user-images.githubusercontent.com/70604577/160039790-122e1a1e-b79a-473e-93ce-42249693f5ae.png)

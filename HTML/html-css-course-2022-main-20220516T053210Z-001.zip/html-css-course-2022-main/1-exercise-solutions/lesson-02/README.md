# Exercises
![exercises2-1](https://user-images.githubusercontent.com/70604577/160036745-268ed519-90ae-4eb4-aa41-ad4785ee6547.png)
![exercises2-2](https://user-images.githubusercontent.com/70604577/160036755-a0f635bf-9d61-4265-a3be-91f180959907.png)

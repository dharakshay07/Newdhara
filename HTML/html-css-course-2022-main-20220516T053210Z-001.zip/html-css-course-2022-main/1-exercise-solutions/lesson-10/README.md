# Exercises
![exercises10-1](https://user-images.githubusercontent.com/70604577/160039160-001662ec-d8c0-487c-adae-c580bc9c27cd.png)
![exercises10-2](https://user-images.githubusercontent.com/70604577/160039175-36fc2add-9700-4b3c-b9c0-b915b5c605c0.png)
![exercises10-3](https://user-images.githubusercontent.com/70604577/160039177-70e49366-1fca-46a5-802b-6bdeef29f2b6.png)

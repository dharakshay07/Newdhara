# Exercises
![exercises17-1](https://user-images.githubusercontent.com/70604577/160040249-40643657-777b-43dd-a69c-503af5f11ebe.png)

https://user-images.githubusercontent.com/70604577/160040463-4bbba430-445d-4dc9-9b86-c4984718380e.mp4

![exercises17-2](https://user-images.githubusercontent.com/70604577/160040519-d9b7c674-11ba-4606-ae21-00aea68f6c10.png)

